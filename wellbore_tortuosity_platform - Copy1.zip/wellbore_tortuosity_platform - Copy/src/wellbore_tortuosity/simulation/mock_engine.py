import pandas as pd


class MockTDBEngine:
    """Mock engine approximating relative T&D&B impact for workflow development.

    This is NOT a replacement for WellScan. It is an interface and sensitivity
    sandbox for comparing smooth vs tortuous trajectory assumptions before or
    after WellScan exports are available.
    """

    def __init__(self, friction_coefficient=0.25, torque_factor=1.0, drag_factor=1.0, buckling_sensitivity=1.0):
        self.mu = friction_coefficient
        self.torque_factor = torque_factor
        self.drag_factor = drag_factor
        self.buckling_sensitivity = buckling_sensitivity

    def run(self, df: pd.DataFrame, dls_col="DLS", tortuosity_col="Tortuosity_Index_Local") -> pd.DataFrame:
        df = df.copy()
        dls = df[dls_col].fillna(0) if dls_col in df.columns else df.get("DLS_Calc", 0)
        tort = df[tortuosity_col].fillna(0) if tortuosity_col in df.columns else 0
        df["Contact_Force_Index"] = self.mu * (1 + 0.25 * dls + 0.35 * tort)
        df["Drag_Index"] = self.drag_factor * df["Contact_Force_Index"].cumsum() / max(len(df), 1)
        df["Torque_Index"] = self.torque_factor * (df["Contact_Force_Index"] * (1 + dls / 10)).cumsum() / max(len(df), 1)
        df["Buckling_Risk_Index"] = self.buckling_sensitivity * (0.4 * dls + 0.6 * tort)
        return df

    def compare_cases(self, smooth_df: pd.DataFrame, tortuous_df: pd.DataFrame) -> dict:
        keys = ["Torque_Index", "Drag_Index", "Buckling_Risk_Index", "Contact_Force_Index"]
        return {
            key: {
                "smooth_max": float(smooth_df[key].max()),
                "tortuous_max": float(tortuous_df[key].max()),
                "relative_change_pct": float((tortuous_df[key].max() - smooth_df[key].max()) / max(smooth_df[key].max(), 1e-9) * 100),
            }
            for key in keys if key in smooth_df.columns and key in tortuous_df.columns
        }
