from pathlib import Path
from jinja2 import Template


REPORT_TEMPLATE = """
# {{ title }}

## Executive Summary
{{ executive_summary }}

## Data Quality Summary
{% for key, value in quality.items() %}
- {{ key }}: {{ value }}
{% endfor %}

## Engineering Observations
{% for obs in observations %}
- {{ obs }}
{% endfor %}

## Recommendations
{% for rec in recommendations %}
- {{ rec }}
{% endfor %}
"""


class ReportGenerator:
    def render_markdown(self, output_path: str | Path, **context) -> Path:
        path = Path(output_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        text = Template(REPORT_TEMPLATE).render(**context)
        path.write_text(text, encoding="utf-8")
        return path
