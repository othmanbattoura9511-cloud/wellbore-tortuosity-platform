class RecommendationEngine:
    def generate(self, quality: dict, summary=None) -> list[str]:
        recs = []
        if quality.get("max_spacing", 0) and quality["max_spacing"] > 30:
            recs.append("Review coarse survey intervals; micro-tortuosity may be under-represented.")
        if quality.get("std_dls", 0) and quality["std_dls"] > quality.get("mean_dls", 0):
            recs.append("DLS variability is high; investigate whether this reflects real tortuosity or survey noise.")
        if quality.get("max_dls", 0) and quality["max_dls"] > 3:
            recs.append("High local DLS observed; evaluate impact on torque, drag, contact forces and buckling.")
        recs.append("Interpret DLS together with survey spacing, drilling system, BHA design and hole section.")
        return recs
