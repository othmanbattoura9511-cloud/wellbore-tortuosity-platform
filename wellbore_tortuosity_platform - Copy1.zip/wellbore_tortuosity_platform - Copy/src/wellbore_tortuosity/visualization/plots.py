import plotly.express as px
import matplotlib.pyplot as plt


class WellPlots:
    def plot_dls(self, df, md_col="MD", dls_col="DLS", color_col=None):
        return px.line(df, x=md_col, y=dls_col, color=color_col, title="DLS vs Measured Depth")

    def plot_inclination(self, df, md_col="MD", inc_col="Inclination", color_col=None):
        return px.line(df, x=md_col, y=inc_col, color=color_col, title="Inclination vs Measured Depth")

    def plot_azimuth(self, df, md_col="MD", azi_col="Azimuth", color_col=None):
        return px.line(df, x=md_col, y=azi_col, color=color_col, title="Azimuth vs Measured Depth")

    def plot_tortuosity_map(self, df, x_col="Local_North", y_col="Local_East", color_col="Tortuosity_Index_Local"):
        if x_col in df.columns and y_col in df.columns:
            return px.scatter(df, x=x_col, y=y_col, color=color_col, title="Tortuosity Map")
        return px.scatter(df, x="MD", y=color_col, color=color_col, title="Tortuosity Index vs MD")
