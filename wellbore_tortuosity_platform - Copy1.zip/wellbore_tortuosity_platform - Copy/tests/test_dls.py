import pandas as pd
from wellbore_tortuosity.analysis.tortuosity import TortuosityAnalyzer


def test_dls_calculation_runs():
    df = pd.DataFrame({"MD": [0, 30], "Inclination": [10, 15], "Azimuth": [20, 25]})
    out = TortuosityAnalyzer().calculate_dls(df)
    assert "DLS_Calc" in out.columns
    assert out["DLS_Calc"].iloc[1] > 0
