# Presentation Structure

1. Title and objective
2. Why tortuosity matters
3. Planned vs actual trajectory
4. Survey limitations and density
5. DLS and tortuosity indicators
6. BHA and drilling system influence
7. Data exploration results
8. Tortuosity characterization framework
9. Simulation workflow: WellScan / mock engine
10. Impact on torque, drag, buckling and contact forces
11. Key findings
12. Recommendations and next steps
