# Suggested 6-Month Weekly Roadmap

## Month 1: Understanding & Framing
- Week 1: Define terminology and thesis scope.
- Week 2: Review literature on trajectory, tortuosity and survey limitations.
- Week 3: Review motor vs RSS behavior and WellScan T&D&B concepts.
- Week 4: Prepare Phase 1 milestone presentation and key questions.

## Month 2: Data Exploration
- Week 5: Collect survey and BHA datasets.
- Week 6: Build data import and cleaning pipeline.
- Week 7: Assess survey density, spacing, quality and consistency.
- Week 8: Produce initial plots and observations.

## Month 3: Tortuosity Characterization
- Week 9: Compute DLS and curvature indicators.
- Week 10: Develop local/global tortuosity metrics.
- Week 11: Compare well sections and drilling systems.
- Week 12: Identify patterns using statistics and clustering.

## Month 4: Simulation & Impact
- Week 13: Define WellScan scenarios.
- Week 14: Compare smooth vs tortuous cases.
- Week 15: Run sensitivity analysis.
- Week 16: Interpret torque, drag, buckling and contact force impact.

## Month 5: Guidelines
- Week 17: Define decision thresholds.
- Week 18: Draft engineering recommendations.
- Week 19: Validate guidelines with case studies.
- Week 20: Prepare Phase 4/5 review.

## Month 6: Thesis & Final Deliverables
- Week 21: Write results and discussion.
- Week 22: Write final recommendations.
- Week 23: Prepare final report and presentation.
- Week 24: Review, polish and submit.
